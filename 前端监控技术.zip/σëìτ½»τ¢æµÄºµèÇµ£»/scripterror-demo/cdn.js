// try {
//     init()
// } catch(err) {
//     throw err;
// }

function init() {
    b=a;
}
// init();