import React from 'react';
import ReactDOM from 'react-dom';
import report from './report';

class Tab extends React.Component {
    constructor (props, context) {
        super(props, context);
    }

    componentDidMount() {

        report.init(this);
    }

    render() {
    

        return (
            <div id="root">
                
            </div>
        );
    }
}
