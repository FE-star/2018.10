import aop from 'aop';

class BaseReport {
    constructor() {}

    init(component) {
        this.component = component; 
        this._init && this._init();
        this._bindEvent && this._bindEvent();
    }

    _init() {
        
    }

    report(data) {
        // reprot something
    }
}


class Report extends BaseReport {
    _init() {
        // 重写父类的init方法 做点自己的事
    }

    _bindEvent() {
        const {
            component
        } = this;

        aop.before(component, 'componentDidMount', () => {
            // report pv
            this.report()
        });
    }
}

export default new Report();
